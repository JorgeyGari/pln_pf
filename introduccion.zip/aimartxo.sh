python -m venv aimartxo
source aimartxo/bin/activate
pip install -r requirements.txt
